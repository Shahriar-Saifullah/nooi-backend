import { Request, Response } from 'express';
import { supabase } from '../services/supabase';
import { SignupInput, LoginInput } from '../schemas/auth.schema';
import { AuthRequest } from '../types';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

// ── SIGNUP ────────────────────────────────────────────────────────────────────
export async function signup(req: Request, res: Response) {
  try {
    const { full_name, email, password } = req.body as SignupInput;

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name },
    });

    if (error) {
      if (error.message.includes('already registered')) {
        return res.status(409).json({
          success: false,
          error: 'An account with this email already exists',
        });
      }
      return res.status(400).json({ success: false, error: error.message });
    }

    return res.status(201).json({
      success: true,
      data: {
        user: {
          id:        data.user.id,
          email:     data.user.email,
          full_name: data.user.user_metadata.full_name,
        },
      },
      message: 'Account created successfully. Please log in.',
    });

  } catch (err) {
    console.error('Signup error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

// ── LOGIN ─────────────────────────────────────────────────────────────────────
export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body as LoginInput;

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password',
      });
    }

    // FIX 1 — Fetch profile from DB (single source of truth)
    const { data: profile } = await supabase
      .from('profiles')
      .select('full_name, plan, onboarding_completed')
      .eq('id', data.user.id)
      .single();

    // FIX 2 — Cookie maxAge changed from 1 hour to 7 days
    res.cookie('access_token', data.session.access_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7 * 1000, // 7 days
      path: '/',
    });

    // FIX 3 — Return plan and onboarding_completed so frontend knows where to redirect
    return res.status(200).json({
      success: true,
      data: {
        user: {
          id:                   data.user.id,
          email:                data.user.email,
          full_name:            profile?.full_name ?? null,
          plan:                 profile?.plan ?? 'free',
          onboarding_completed: profile?.onboarding_completed ?? false,
        },
      },
    });

  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

// ── LOGOUT ────────────────────────────────────────────────────────────────────
export async function logout(req: Request, res: Response) {
  try {
    res.clearCookie('access_token', {
      path: '/',
    });
    return res.status(200).json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

// ── GOOGLE SIGN IN ────────────────────────────────────────────────────────────
export async function googleSignIn(req: Request, res: Response) {
  try {
    const verifier = crypto.randomBytes(32).toString('base64url');
    const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');

    res.cookie('sb-code-verifier', verifier, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 10 * 60 * 1000,
    });

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: process.env.SUPABASE_REDIRECT_URL,
        queryParams: {
          code_challenge: challenge,
          code_challenge_method: 'S256',
        },
      },
    });

    if (error) throw error;
    if (data.url) {
      return res.redirect(data.url);
    }

    return res.status(400).json({ success: false, error: 'Could not generate Google login URL' });
  } catch (err: any) {
    console.error('Google Sign-in error:', err);
    return res.status(500).json({ success: false, error: err.message || 'Internal server error' });
  }
}

// ── AUTH CALLBACK (Google OAuth) ──────────────────────────────────────────────
export async function authCallback(req: Request, res: Response) {
  try {
    const code = req.query.code as string;
    const verifier = req.cookies['sb-code-verifier'];

    if (!code) {
      return res.status(400).json({
        success: false,
        error: 'Authorization code missing. Please start the login flow from /auth/google.',
      });
    }

    if (!verifier) {
      return res.status(400).json({
        success: false,
        error: 'Code verifier missing. Your session may have timed out or cookies are blocked.',
      });
    }

    const tempSupabase = createClient(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_ANON_KEY!,
      {
        auth: {
          flowType: 'pkce',
          storage: {
            getItem: (key: string) => {
              if (key.endsWith('code-verifier')) return verifier;
              return null;
            },
            setItem: () => {},
            removeItem: () => {},
          },
        },
      }
    );

    const { data, error } = await tempSupabase.auth.exchangeCodeForSession(code);
    if (error) throw error;

    res.clearCookie('sb-code-verifier');

    // FIX 4 — Fetch profile for Google OAuth users too
    const { data: profile } = await supabase
      .from('profiles')
      .select('full_name, plan, onboarding_completed')
      .eq('id', data.user.id)
      .single();

    // FIX 5 — Cookie maxAge 7 days
    res.cookie('access_token', data.session.access_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7 * 1000, // 7 days
      path: '/',
    });

    return res.status(200).json({
      success: true,
      message: 'Logged in successfully with Google',
      data: {
        user: {
          id:                   data.user.id,
          email:                data.user.email,
          full_name:            profile?.full_name ?? null,
          plan:                 profile?.plan ?? 'free',
          onboarding_completed: profile?.onboarding_completed ?? false,
        },
      },
    });

  } catch (err: any) {
    console.error('OAuth Callback error:', err);
    return res.status(500).json({ success: false, error: err.message || 'Internal server error' });
  }
}

// ── GET ME ────────────────────────────────────────────────────────────────────
export async function getMe(req: AuthRequest, res: Response) {
  try {
    const userId = req.user!.id;

    // FIX 6 — Fetch from profiles table not from req.user
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('id, full_name, avatar_url, plan, onboarding_completed, created_at')
      .eq('id', userId)
      .single();

    if (error || !profile) {
      return res.status(404).json({ success: false, error: 'Profile not found' });
    }

    return res.status(200).json({
      success: true,
      data: {
        user: {
          id:                   profile.id,
          email:                req.user!.email,
          full_name:            profile.full_name,
          avatar_url:           profile.avatar_url,
          plan:                 profile.plan,
          onboarding_completed: profile.onboarding_completed,
        },
      },
    });

  } catch (err) {
    console.error('GetMe error:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}